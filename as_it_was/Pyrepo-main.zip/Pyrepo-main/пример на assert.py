def quarter(x, y):
    return ''


assert quarter(3, 4) == 'I четверть'
assert quarter(-3.5, 8) == 'II четверть'