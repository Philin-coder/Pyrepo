import random

print(random.randint(int(input("начало ")), int(input("конец "))))
