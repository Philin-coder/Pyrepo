a = int(input())
b = a - 1
c = a + 1
print("The next number for the number", b, "is", c, '.')  # print старый
print("The next number for the number", b, "is", b - 1, '.')
print(f'фраща  {b} и {c}')  # print новый, где f- фраза, а {b} и {c} - результирующие
