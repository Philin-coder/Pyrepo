import pyautogui
import time

time.sleep(2)
pyautogui.click(x=80, y=200)
time.sleep(2)
pyautogui.moveTo(700, 500)
time.sleep(2)
pyautogui.rightClick(700, 500)
time.sleep(2)
pyautogui.rightClick(710, 510)
time.sleep(2)
pyautogui.moveTo(720, 520)
time.sleep(2)
pyautogui.rightClick(720, 520)
time.sleep(2)
pyautogui.moveTo(850, 860)
