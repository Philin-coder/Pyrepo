a, x, b = (input().split())

a = int(a)
b = int(b)
print(x * (a - b))
