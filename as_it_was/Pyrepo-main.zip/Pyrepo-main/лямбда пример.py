n=int(input())
f=lambda n:n%5==0
print(f(n))