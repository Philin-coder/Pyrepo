def func(a, b):
    res = a + b
    print(res)
    return res


if __name__ == '__main__':
    a = int(input())
    b = int(input())
    func(a, b)
