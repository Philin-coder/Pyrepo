import math

d = float(input("введите диаметр "))
p = math.pi * d
s = (math.pi * d * d) / 4
print("площадь окружности равна и длина", ' ', "%.4f" % s, ' ', "%4.f" % p)
