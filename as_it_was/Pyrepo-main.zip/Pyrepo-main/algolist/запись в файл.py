with open(my_filename + '.' + fext2, 'w', encoding='utf-8') as fp:
    print(linklist, file=fp, sep="\n")
