import os
from os import listdir

print('\n'.join(listdir(os.getcwd())))
