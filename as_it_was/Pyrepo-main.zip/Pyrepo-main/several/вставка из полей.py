cursor.execute("INSERT INTO table VALUES (%s, %s, %s)", (var1, var2, var3))
