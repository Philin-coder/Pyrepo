import numpy as np


def massummer():
    a = np.array([[2, 4],
                  [6, 8],
                  [10, 12]])
    b = np.array([[2, 4],
                  [6, 8],
                  [10, 12]])

    print(a + b)


if __name__ == '__main__':
    massummer()
