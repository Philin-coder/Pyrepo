Simple, but usefull pices of code on python3
