import math


def nod(a, b):
    print(math.gcd(a, b))


if __name__ == '__main__':
    a = int(input())
    b = int(input())
    nod(a, b)
