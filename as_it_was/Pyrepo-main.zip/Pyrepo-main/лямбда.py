func = lambda x, y: x ** 2 + y ** 2
print(func(1, 4))
