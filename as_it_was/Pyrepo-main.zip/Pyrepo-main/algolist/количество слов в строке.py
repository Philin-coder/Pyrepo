def wordcount(s):
    print(len(s))


if __name__ == '__main__':
    s = input().split()
    wordcount(s)
