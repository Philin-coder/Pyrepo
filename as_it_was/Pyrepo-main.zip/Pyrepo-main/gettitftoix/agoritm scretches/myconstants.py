from urllib.request import urlopen
status=200
fext='mp3'
fext2='txt'
myhttp='http://best-muzon.cc/dl/online/MkZsKiEODTJyaNjIFSTHQA/1502180287/songs12/2017/01/luis-fonsi-feat.-daddy-yankee-despacito-(best-muzon.cc).mp3'

URL='http://mp3cc.com/'





