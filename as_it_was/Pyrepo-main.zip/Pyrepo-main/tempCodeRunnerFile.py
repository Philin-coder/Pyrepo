import random
def how_are_you(mstring):
    print('Thenks,I am fine')

if __name__ == "__main__":
    mstring=input()
    how_are_you(mstring)
