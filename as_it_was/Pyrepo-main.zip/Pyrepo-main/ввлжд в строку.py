def inp(c):
    print(c)
    print(type(c))


if __name__ == '__main__':
    c = input().split()
    inp(c)
