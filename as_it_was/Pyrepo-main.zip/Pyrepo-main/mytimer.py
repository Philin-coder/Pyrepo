import time


def test(mstring):
    print(mstring)
    # вызов Ваших ф-ций.
    time.sleep(
        x)  # посколльку,нужно просто заставить функцию работать раз в x времении, задавая x руками(x 18*60)? поделенноое на равные части,  то


if __name__ == '__main__':
    x = int(input())
    while True:
        test(mstring='проба')
