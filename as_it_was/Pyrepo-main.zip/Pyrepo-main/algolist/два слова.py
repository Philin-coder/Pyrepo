# раз два
s = ' '.join(input().split(' ')[::-1])
# два раз
