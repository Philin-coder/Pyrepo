print(sum([d[i] for i in range(len(d) - 1, k, -1)]))
