a, b = map(int, input().split())
res = a + b
print(res)
