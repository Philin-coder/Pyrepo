import os

os.system('chcp.{}.>nul'.format('1251'))
