import vobject

cal = vobject.newFromBehavior('vcalendar')
cal.behavior
print(cal)
