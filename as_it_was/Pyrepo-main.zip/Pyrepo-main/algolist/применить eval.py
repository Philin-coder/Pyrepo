import math


def demo(x):
    res = eval('x**2')
    print(res)
    return res


if __name__ == '__main__':
    x = int(input())
    demo(x)
