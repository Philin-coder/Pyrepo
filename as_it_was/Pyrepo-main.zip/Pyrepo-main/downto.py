def loopback(n):
    for i in reversed(range(n)):
        print(i)


if __name__ == '__main__':
    loopback(n=12)
