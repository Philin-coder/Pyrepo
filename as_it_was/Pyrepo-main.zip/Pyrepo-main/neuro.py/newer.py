print ('it is alive')
def