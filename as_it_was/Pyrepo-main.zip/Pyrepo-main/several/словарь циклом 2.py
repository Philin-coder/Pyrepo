result = dict(zip(key_list, range(1, 1 + len(key_list))))
print(result)
