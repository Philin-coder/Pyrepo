def inp(c):
    print(list(c))


if __name__ == '__main__':
    c = map(int, input().split())
    inp(c)
