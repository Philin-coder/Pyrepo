Python Utils.
