import pyautogui

pyautogui.click(500, 500);
pyautogui.typewrite('Hello world!')
