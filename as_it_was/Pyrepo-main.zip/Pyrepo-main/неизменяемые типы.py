def immut():
    t = (1, 1)
    print(t)
    print(type(t))


if __name__ == '__main__':
    immut()
