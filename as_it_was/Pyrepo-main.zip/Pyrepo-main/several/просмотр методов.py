import os

for i in dir(os):
    print(i)
