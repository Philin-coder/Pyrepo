Litle pices programms on python

