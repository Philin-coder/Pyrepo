def test():
    for i in range(1, 10):
        for j in range(1, 10):
            print(i * j, end=" ")
        print("")


if __name__ == '__main__':
    test()
