# uhfabr a=wnn
import math


def graph(x, y):
    if x == 0 and y == -2:
        res = ((x ** 2) / 2) - 2
    print(res)
    return res


if __name__ == '__main__':
    x = int(input())
    y = int(input())
    graph(x, y)
